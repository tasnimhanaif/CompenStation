// Everything that happens on the Employees page of the admin
//import { employees } from "./sampleData";

// Element variables
const employeeTableBody = document.querySelector("#employeeTableBody");
const archiveTableBody = document.querySelector("#archiveTableBody");
const addEmployeeBtn = document.querySelector("#addEmployeeBtn");
const employeeForm = document.querySelector("#employeeForm");
const employeeTable = document.querySelector("#employeeTable");
const submitBtn = document.querySelector("#employeeSubmit");
// let employees = [];  <-- we'll keep the employee list in memory after the fetch call

// ---Show Add Employees screen
addEmployeeBtn.addEventListener("click", () => {
      openAddForm();
});

// input validation for Pay input field on add/edit employee
document.querySelectorAll(
    "#employeeForm input[name='pay']"
).forEach(input => {
    input.addEventListener("input", () => {
        input.value = input.value.replace(/[^0-9.]/g, "").replace(/(\..*?)\..*/g, "$1");
    });
});

// Cancel on Add/Edit employee returns to employees list
document.querySelector("#addEditEmployee .btn-tertiary").addEventListener("click", () => {
      showPage("employees");
});

function createStatusCell(currentStatus) {
      const statuses = ['active', 'terminated', 'quit', 'disabled', 'retired'];
      return `
            <span class="status-badge status-${currentStatus}">
                  <select>
                        ${statuses.map(s =>
                              `<option value="${s}" ${currentStatus === s ? 'selected' : ''}>${s.charAt(0).toUpperCase() + s.slice(1)}</option>`
                        ).join('')}
                  </select>
            </span>
      `;
}

function createEmployeeRow(employee) {
      const row = document.createElement("tr");
      const hoursDisplay = employee.payType === "salary" ? "N/A" : employee.hoursWorked;
      row.innerHTML = `
            <td>${employee.firstName} ${employee.lastName}</td>
            <td>$${(employee.pay).toLocaleString('en-US', {minimumFractionDigits: 0, maximumFractionDigits: 0})}${employee.payType === 'hourly' ? '/hr' : '/yr'}</td>
            <td>${employee.jobTitle}</td>
            <td>${hoursDisplay}</td>
            <td class="status-cell">${createStatusCell(employee.status)}</td>
            <td><button class="edit-btn">Edit</button></td>
      `;
      row.querySelector('.edit-btn').addEventListener('click', () => {
            openEditForm(employee);
      });
      row.querySelector('select').addEventListener('change', (e) => {
            const newStatus = e.target.value;
            employee.status = newStatus;
            employee.statusChangeDate = Intl.DateTimeFormat("en-US").format(new Date());
            // Update badge color in place
            const badge = row.querySelector('.status-badge');
            badge.className = `status-badge status-${newStatus}`;
            if (newStatus !== 'active') {
                  // Move out of active list
                  loadActiveEmployees();
                  loadArchivedEmployees();
                  refreshDashboard();
                  if (typeof showToast === 'function') showToast(`${employee.firstName} ${employee.lastName} archived (${newStatus})`);
            }
      });
      return row;
}

function createArchiveRow(employee) {
      const row = document.createElement('tr');
      row.innerHTML = `
            <td>${employee.firstName} ${employee.lastName}</td>
            <td class="status-cell">${createStatusCell(employee.status)}</td>
            <td>${employee.statusChangeDate}</td>
      `;
      row.querySelector('select').addEventListener('change', (e) => {
            const newStatus = e.target.value;
            employee.status = newStatus;
            employee.statusChangeDate = Intl.DateTimeFormat("en-US").format(new Date());
            const badge = row.querySelector('.status-badge');
            badge.className = `status-badge status-${newStatus}`;
            if (newStatus === 'active') {
                  loadActiveEmployees();
                  loadArchivedEmployees();
                  refreshDashboard();
                  if (typeof showToast === 'function') showToast(`${employee.firstName} ${employee.lastName} restored to active`);
            } else {
                  row.cells[2].textContent = employee.statusChangeDate;
                  refreshDashboard();
            }
      });
      return row;
}

// ─── Filter state ────────────────────────────────────────────────────────────
let currentSearchTerm = '';
let currentStatusFilter = 'all';

function getFilteredActive() {
      const term = currentSearchTerm.toLowerCase();
      return employees.filter(e => {
            if (e.status !== 'active') return false;
            if (currentStatusFilter !== 'all' && e.status !== currentStatusFilter) return false;
            if (!term) return true;
            return (
                  e.firstName.toLowerCase().includes(term) ||
                  e.lastName.toLowerCase().includes(term) ||
                  (e.jobTitle || '').toLowerCase().includes(term) ||
                  String(e.employeeID).includes(term)
            );
      });
}

function getFilteredArchived() {
      const term = currentSearchTerm.toLowerCase();
      return employees.filter(e => {
            if (e.status === 'active') return false;
            if (currentStatusFilter !== 'all' && currentStatusFilter !== 'active' && e.status !== currentStatusFilter) return false;
            if (!term) return true;
            return (
                  e.firstName.toLowerCase().includes(term) ||
                  e.lastName.toLowerCase().includes(term) ||
                  (e.jobTitle || '').toLowerCase().includes(term) ||
                  String(e.employeeID).includes(term)
            );
      });
}

function loadActiveEmployees() {
      employeeTableBody.innerHTML = '';
      const list = getFilteredActive();
      if (list.length === 0) {
            const empty = document.createElement('tr');
            empty.className = 'empty-row';
            empty.innerHTML = `<td colspan="6">No employees match your filters</td>`;
            employeeTableBody.appendChild(empty);
            return;
      }
      list.forEach(employee => {
            employeeTableBody.appendChild(createEmployeeRow(employee));
      });
}

function loadArchivedEmployees() {
      archiveTableBody.innerHTML = '';
      const list = getFilteredArchived();
      if (list.length === 0) {
            const empty = document.createElement('tr');
            empty.className = 'empty-row';
            empty.innerHTML = `<td colspan="3">No archived employees</td>`;
            archiveTableBody.appendChild(empty);
            return;
      }
      list.forEach(employee => {
            archiveTableBody.appendChild(createArchiveRow(employee));
      });
}

// Backward-compatible alias used by other files
function loadSampleEmployees() {
      loadActiveEmployees();
      loadArchivedEmployees();
}

// ─── Search + filter wiring ──────────────────────────────────────────────────
const employeeSearchInput = document.querySelector('#employeeSearchInput');
const employeeStatusFilter = document.querySelector('#employeeStatusFilter');
if (employeeSearchInput) {
      employeeSearchInput.addEventListener('input', (e) => {
            currentSearchTerm = e.target.value;
            loadActiveEmployees();
      });
}
if (employeeStatusFilter) {
      employeeStatusFilter.addEventListener('change', (e) => {
            currentStatusFilter = e.target.value;
            loadActiveEmployees();
      });
}

document.addEventListener('DOMContentLoaded', () => {
      loadActiveEmployees();
      loadArchivedEmployees();
      refreshDashboard();
});

// Load employee form. Add employee empty, and Edit employee pre-filled
let prefilledData = null;
function openAddForm() {
      prefilledData = null;
      screenName.textContent = "Add Employee";
      document.querySelector("#employeeForm").reset();
      renderBenefitsCheckboxes();
      showPage("addEditEmployee");
      submitBtn.innerHTML = "Add";
}
function fillForm(employee) {
  const form = document.getElementById('employeeForm');
  for (const [key, value] of Object.entries(employee)) {
    if (form.elements[key]) {
      form.elements[key].value = value ?? '';
    }
  }
}
function openEditForm(employee) {
      prefilledData = employee.employeeID;
      screenName.textContent = "Edit Employee";
      fillForm(employee);
      renderBenefitsCheckboxes(employee.benefits ?? []);
      showPage("addEditEmployee");
      submitBtn.innerHTML = "Save";
}

const benefitsCheckboxes = document.querySelector("#benefitsCheckboxes");
function renderBenefitsCheckboxes(employeeBenefits = []) {
    benefitsCheckboxes.innerHTML = '';
    benefits.forEach(benefit => {
        const label = document.createElement('label');
        label.className = 'benefit-checkbox';

        const input = document.createElement('input');
        input.type = 'checkbox';
        input.name = 'benefits';
        input.value = benefit.name;
        input.checked = employeeBenefits.includes(benefit.name);

        label.appendChild(input);
        label.append(' ' + benefit.name);
        benefitsCheckboxes.appendChild(label);
    });
}
function generateEmployeeID() {
    if (employees.length === 0) return 1;
    return Math.max(...employees.map(emp => emp.employeeID)) + 1;
}

document.querySelector("#employeeForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);
    data.benefits = formData.getAll('benefits');

    // Coerce numeric fields, guarding against empty strings
    data.pay = parseFloat(data.pay) || 0;
    data.hoursWorked = parseFloat(data.hoursWorked) || 0;

    // Make sure employeeID never sneaks in as a string
    delete data.employeeID;

    if (prefilledData == null) {
        // ADD
        data.employeeID = generateEmployeeID();
        data.status = 'active';                    // <-- the missing piece
        data.statusChangeDate = Intl.DateTimeFormat("en-US").format(new Date());
        employees.push(data);
        if (typeof showToast === 'function') showToast(`${data.firstName} ${data.lastName} added (ID ${data.employeeID})`);
    } else {
        // EDIT
        const idx = employees.findIndex(emp => emp.employeeID === prefilledData);
        if (idx !== -1) {
            employees[idx] = { ...employees[idx], ...data };
            if (typeof showToast === 'function') showToast(`${data.firstName} ${data.lastName} updated`);
        }
    }

    loadSampleEmployees();
    refreshDashboard();
    showPage("employees");
});

// ---------------------------------------
//     B U T T O N S
//----------------------------------------  
 
// Archive Button
const archiveBtn = document.querySelector("#archiveBtn");
archiveBtn.addEventListener("click", () => {
      showPage("archive");
})

// Back Button on Archive screen
const backBtn = document.querySelector("#backBtn");
backBtn.addEventListener("click", () => {
      showPage("employees");
})