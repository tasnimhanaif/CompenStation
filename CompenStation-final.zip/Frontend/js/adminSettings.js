// Everything that happens on the Settings page of the admin

// ─── Number-only enforcement for percentage inputs ────────────────────────────
document.querySelectorAll(
    "#benefitPercentageInput,\
      #stateTaxPercentageInput,\
      #federalTaxPercentageInput,\
      #stateTaxBracketStartInput,\
      #federalTaxBracketStartInput"
    ).forEach(input => {
        input.addEventListener("input", () => {
              input.value = input.value.replace(/[^0-9.]/g, "").replace(/(\..*?)\..*/g, "$1");
        });
});

// Adding a benefit
const benefitsForm = document.querySelector("#benefitsForm");
benefitsForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const formData = new FormData(benefitsForm);
    const benefitItem = Object.fromEntries(formData.entries());
    if (!benefitItem.name || !benefitItem.name.trim()) {
        if (typeof showToast === 'function') showToast("Benefit name is required", "error");
        return;
    }
    benefitItem.percentage = parseFloat(benefitItem.percentage) || 0;
    if (!benefits.some(item => item.name === benefitItem.name)) {
        benefits.push(benefitItem);
        if (typeof showToast === 'function') showToast(`Added benefit: ${benefitItem.name}`);
    } else {
        if (typeof showToast === 'function') showToast(`Benefit "${benefitItem.name}" already exists`, "error");
    }
    loadSampleBenefits();
    benefitsForm.reset();
});

// Removing a benefit
const removeBenefitBtn = document.querySelector("#removeBenefitBtn");
removeBenefitBtn.addEventListener("click", (e) => {
    e.preventDefault();
    const selected = benefitsList.querySelector(".list-item.active");
    if (!selected) {
        if (typeof showToast === 'function') showToast("Select a benefit to remove", "error");
        return;
    }
    const idx = benefits.findIndex(b => b.name === selected.dataset.id);
    if (idx !== -1) {
        const removed = benefits.splice(idx, 1)[0];
        if (typeof showToast === 'function') showToast(`Removed benefit: ${removed.name}`);
    }
    loadSampleBenefits();
});

// Adding a state tax
const stateTaxForm = document.querySelector("#stateTaxForm");
stateTaxForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const formData = new FormData(stateTaxForm);
    const taxItem = Object.fromEntries(formData.entries());
    // Coerce numeric so dedupe and sorting work correctly
    taxItem.percentage = parseFloat(taxItem.percentage) || 0;
    taxItem.bracketStart = parseFloat(taxItem.bracketStart) || 0;
    const dup = stateTaxes.some(item =>
        parseFloat(item.percentage) === taxItem.percentage &&
        parseFloat(item.bracketStart) === taxItem.bracketStart
    );
    if (!dup) {
        stateTaxes.push(taxItem);
        if (typeof showToast === 'function') showToast(`Added state tax: ${taxItem.percentage}% from $${taxItem.bracketStart}`);
    } else {
        if (typeof showToast === 'function') showToast("State tax bracket already exists", "error");
    }
    loadSampleStateTax();
    stateTaxForm.reset();
});

// Removing a state tax
const removeStateTaxBtn = document.querySelector("#removeStateTaxBtn");
removeStateTaxBtn.addEventListener("click", (e) => {
    e.preventDefault();
    const selected = stateTaxList.querySelector(".list-item.active");
    if (!selected) {
        if (typeof showToast === 'function') showToast("Select a state tax to remove", "error");
        return;
    }
    const idx = parseInt(selected.dataset.index, 10);
    if (!isNaN(idx) && idx >= 0 && idx < stateTaxes.length) {
        const removed = stateTaxes.splice(idx, 1)[0];
        if (typeof showToast === 'function') showToast(`Removed state tax: ${removed.percentage}%`);
    }
    loadSampleStateTax();
});

// Adding a federal tax
const federalTaxForm = document.querySelector("#federalTaxForm");
federalTaxForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const formData = new FormData(federalTaxForm);
    const taxItem = Object.fromEntries(formData.entries());
    taxItem.percentage = parseFloat(taxItem.percentage) || 0;
    taxItem.bracketStart = parseFloat(taxItem.bracketStart) || 0;
    const dup = federalTaxes.some(item =>
        parseFloat(item.percentage) === taxItem.percentage &&
        parseFloat(item.bracketStart) === taxItem.bracketStart
    );
    if (!dup) {
        federalTaxes.push(taxItem);
        if (typeof showToast === 'function') showToast(`Added federal tax: ${taxItem.percentage}% from $${taxItem.bracketStart}`);
    } else {
        if (typeof showToast === 'function') showToast("Federal tax bracket already exists", "error");
    }
    loadSampleFederalTax();
    federalTaxForm.reset();
});

// Removing a federal tax
const removeFederalTaxBtn = document.querySelector("#removeFederalTaxBtn");
removeFederalTaxBtn.addEventListener("click", (e) => {
    e.preventDefault();
    const selected = federalTaxList.querySelector(".list-item.active");
    if (!selected) {
        if (typeof showToast === 'function') showToast("Select a federal tax to remove", "error");
        return;
    }
    const idx = parseInt(selected.dataset.index, 10);
    if (!isNaN(idx) && idx >= 0 && idx < federalTaxes.length) {
        const removed = federalTaxes.splice(idx, 1)[0];
        if (typeof showToast === 'function') showToast(`Removed federal tax: ${removed.percentage}%`);
    }
    loadSampleFederalTax();
});

const benefitsList = document.querySelector("#benefitsList");
const stateTaxList = document.querySelector("#stateTaxList");
const federalTaxList = document.querySelector("#federalTaxList");
function createListItem(item, type, index) {
    const listItem = document.createElement("li");
    listItem.className = "list-item";
    if (type == "benefitList") {
        listItem.textContent = `${item.name} — ${item.percentage}%`;
        listItem.dataset.id = item.name;
    } else if (type == "stateTaxList" || type == "federalTaxList") {
        listItem.textContent = `${item.percentage}% from $${Number(item.bracketStart).toLocaleString()}`;
        listItem.dataset.id = item.percentage;
        listItem.dataset.index = index;
    } else {
        console.log("createListItem(item, type): Invalid list item type!");
        return;
    }
    listItem.addEventListener("click", () => {
        fillSettingsForm(item, type);
    });
    return listItem;
}
function loadSampleBenefits() {
      benefitsList.innerHTML = '';
      benefits.forEach((benefit, i) => {
            benefitsList.appendChild(createListItem(benefit, "benefitList", i));
      });
}
function loadSampleStateTax() {
    stateTaxList.innerHTML = '';
    stateTaxes.forEach((stateTax, i) => {
        stateTaxList.appendChild(createListItem(stateTax, "stateTaxList", i));
    });
}
function loadSampleFederalTax() {
    federalTaxList.innerHTML = '';
    federalTaxes.forEach((federalTax, i) => {
        federalTaxList.appendChild(createListItem(federalTax, "federalTaxList", i));
    });
}
document.addEventListener('DOMContentLoaded', () => {
    loadSampleBenefits();
    loadSampleStateTax();
    loadSampleFederalTax();
});

// Handle higlighting list items on the benefits list
benefitsList.addEventListener("click", (e) => {
    const item = e.target.closest(".list-item");
    if (!item) return;
    benefitsList.querySelectorAll(".list-item").forEach(i => i.classList.remove("active"));
    item.classList.add("active");
});
// Handle higlighting list items on the state tax list
stateTaxList.addEventListener("click", (e) => {
    const item = e.target.closest(".list-item");
    if (!item) return;
    stateTaxList.querySelectorAll(".list-item").forEach(i => i.classList.remove("active"));
    item.classList.add("active");
});
// Handle higlighting list items on the federal tax list
federalTaxList.addEventListener("click", (e) => {
    const item = e.target.closest(".list-item");
    if (!item) return;
    federalTaxList.querySelectorAll(".list-item").forEach(i => i.classList.remove("active"));
    item.classList.add("active");
});
function fillSettingsForm(item, type) {
    if (type === "benefitList") {
        document.getElementById("benefitPercentageInput").value = item.percentage ?? '';
        document.getElementById("benefitNameInput").value = item.name ?? '';
    } else if (type === "stateTaxList") {
        document.getElementById("stateTaxPercentageInput").value = item.percentage ?? '';
        document.getElementById("stateTaxBracketStartInput").value = item.bracketStart ?? '';
    } else if (type === "federalTaxList") {
        document.getElementById("federalTaxPercentageInput").value = item.percentage ?? '';
        document.getElementById("federalTaxBracketStartInput").value = item.bracketStart ?? '';
    }
}