// Employee page logic
// Reads `employees`, `benefits`, `stateTaxes`, `federalTaxes` from sampleData.js

// ─── Constants ───────────────────────────────────────────────────────────────
const MED_COSTS = { none: 0, ppo: 150, hmo: 120 };
const VIS_COSTS = { none: 0, standard: 20, premium: 45 };
const FICA_RATE = 0.0765;
const PAY_PERIODS_PER_YEAR = 26; // bi-weekly

// ─── Current employee (in a real app this would come from auth) ──────────────
// For now, default to employee #2 (Gerald, an active salaried employee).
// Pickable via ?id=12345679 in the URL for demoing different users.
let currentEmployee = (function () {
    const params = new URLSearchParams(window.location.search);
    const reqId = params.get('id');
    if (reqId) {
        const found = employees.find(e => String(e.employeeID) === reqId);
        if (found) return found;
    }
    // Default to first non-admin active employee
    return employees.find(e => e.accountType !== 'Admin' && e.status === 'active') || employees[1] || employees[0];
})();

// ─── Toast (shared with admin) ───────────────────────────────────────────────
let _toastTimer = null;
function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.remove('toast-error');
    if (type === 'error') toast.classList.add('toast-error');
    toast.classList.add('show');
    clearTimeout(_toastTimer);
    _toastTimer = setTimeout(() => toast.classList.remove('show'), 3000);
}

// ─── Page navigation ─────────────────────────────────────────────────────────
const pages = document.querySelectorAll('.page');
const navLinks = document.querySelectorAll('.nav-link');
const screenName = document.querySelector('#screen');

function showPage(id) {
    pages.forEach(p => p.style.display = 'none');
    const el = document.getElementById(id);
    if (el) el.style.display = 'flex';
}

function setActiveLink(activeLink) {
    navLinks.forEach(l => {
        l.classList.remove('active');
        const img = l.querySelector('img');
        if (img) img.src = img.src.replace('_light.svg', '_dark.svg');
    });
    activeLink.classList.add('active');
    const img = activeLink.querySelector('img');
    if (img) img.src = img.src.replace('_dark.svg', '_light.svg');
}

navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const target = link.dataset.target;
        showPage(target);
        setActiveLink(link);
        screenName.textContent = link.textContent.trim();
    });
});

// ─── Tax math (progressive) ──────────────────────────────────────────────────
function calcProgressiveTax(annualSalary, brackets) {
    if (annualSalary <= 0 || !brackets || !brackets.length) return 0;
    // Sort by bracket_start ascending so we can iterate cleanly
    const sorted = [...brackets].sort((a, b) => Number(a.bracketStart) - Number(b.bracketStart));
    let total = 0;
    for (let i = 0; i < sorted.length; i++) {
        const start = Number(sorted[i].bracketStart);
        const end = i + 1 < sorted.length ? Number(sorted[i + 1].bracketStart) : Infinity;
        if (annualSalary <= start) break;
        const taxableInBracket = Math.min(annualSalary, end) - start;
        total += taxableInBracket * (Number(sorted[i].percentage) / 100);
    }
    return total;
}

// ─── Pay calculation ─────────────────────────────────────────────────────────
function calcPay(emp) {
    let grossBiweekly = 0;
    if (emp.payType === 'salary') {
        grossBiweekly = (emp.pay || 0) / PAY_PERIODS_PER_YEAR;
    } else {
        // Hourly: pay rate * hours worked this period
        grossBiweekly = (emp.pay || 0) * (emp.hoursWorked || 0);
    }

    const annualizedGross = grossBiweekly * PAY_PERIODS_PER_YEAR;
    const annualFed = calcProgressiveTax(annualizedGross, federalTaxes);
    const annualState = calcProgressiveTax(annualizedGross, stateTaxes);

    const fedTax = annualFed / PAY_PERIODS_PER_YEAR;
    const stateTax = annualState / PAY_PERIODS_PER_YEAR;
    const fica = grossBiweekly * FICA_RATE;
    const medCost = MED_COSTS[emp.medPlan] || 0;
    const visCost = VIS_COSTS[emp.visPlan] || 0;

    const net = Math.max(0, grossBiweekly - fedTax - stateTax - fica - medCost - visCost);

    return { gross: grossBiweekly, fedTax, stateTax, fica, medCost, visCost, net };
}

// ─── Render: header + tags ───────────────────────────────────────────────────
function renderProfileHeader() {
    const e = currentEmployee;
    if (!e) return;
    document.getElementById('userName').textContent = `${e.firstName} ${e.lastName}`;
    document.getElementById('empName').textContent = `${e.firstName} ${e.lastName}`;
    document.getElementById('empTitle').textContent = e.jobTitle || '';
    document.getElementById('empAvatar').textContent = (e.firstName[0] || '') + (e.lastName[0] || '');
    document.getElementById('empStateTag').textContent = `Tax: ${e.state}`;
    document.getElementById('empTypeTag').textContent = e.payType === 'salary' ? 'Salaried' : 'Hourly';
    const statusTag = document.getElementById('empStatusTag');
    statusTag.textContent = e.status;
    // Reuse admin status badge palette
    statusTag.style.background = ({
        active: '#dcfce7',
        terminated: '#fee2e2',
        retired: '#fef9c3',
        quit: '#f3f4f6',
        disabled: '#e0e7ff',
    })[e.status] || '#dcfce7';
    statusTag.style.color = ({
        active: '#166534',
        terminated: '#991b1b',
        retired: '#854d0e',
        quit: '#4b5563',
        disabled: '#3730a3',
    })[e.status] || '#166534';

    // Part-time warning visibility
    const ptWarn = document.getElementById('empPartTimeWarning');
    ptWarn.style.display = e.employmentType === 'part-time' ? 'block' : 'none';
}

// ─── Render: pay breakdown ───────────────────────────────────────────────────
function renderPayBreakdown() {
    const e = currentEmployee;
    if (!e) return;
    const p = calcPay(e);
    const fmt = (n) => '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    document.getElementById('empPayBreakdown').innerHTML = `
        <div class="emp-pay-row emp-pay-gross"><span>Gross Earnings</span><span>${fmt(p.gross)}</span></div>
        <div class="emp-pay-row emp-pay-deduction"><span>Federal Tax</span><span>-${fmt(p.fedTax)}</span></div>
        <div class="emp-pay-row emp-pay-deduction"><span>State Tax (${e.state})</span><span>-${fmt(p.stateTax)}</span></div>
        <div class="emp-pay-row emp-pay-deduction"><span>FICA</span><span>-${fmt(p.fica)}</span></div>
        <div class="emp-pay-row emp-pay-deduction"><span>Medical</span><span>-${fmt(p.medCost)}</span></div>
        <div class="emp-pay-row emp-pay-deduction"><span>Vision</span><span>-${fmt(p.visCost)}</span></div>
        <div class="emp-pay-row emp-pay-net"><span>Net Pay</span><span>${fmt(p.net)}</span></div>
    `;

    // Fiscal lock for non-active
    const isLocked = e.status !== 'active';
    document.getElementById('empGenerateCheckBtn').disabled = isLocked;
    document.getElementById('empGenerateCheckBtn').style.opacity = isLocked ? 0.5 : 1;
    document.getElementById('empFiscalLock').style.display = isLocked ? 'block' : 'none';
}

// ─── Render: benefit selects on dashboard ────────────────────────────────────
function renderBenefitSelects() {
    const e = currentEmployee;
    if (!e) return;
    document.getElementById('empMedical').value = e.medPlan || 'none';
    document.getElementById('empVision').value = e.visPlan || 'none';
}

// ─── Render: full benefits page ──────────────────────────────────────────────
function renderBenefitsList() {
    const e = currentEmployee;
    if (!e) return;
    const list = document.getElementById('empBenefitsList');
    list.innerHTML = '';
    benefits.forEach(b => {
        const li = document.createElement('li');
        li.className = 'emp-benefit-item';
        const isChecked = (e.benefits || []).includes(b.name);
        const grossBiweekly = e.payType === 'salary' ? e.pay / PAY_PERIODS_PER_YEAR : e.pay * (e.hoursWorked || 0);
        const cost = grossBiweekly * (Number(b.percentage) / 100);
        li.innerHTML = `
            <input type="checkbox" data-name="${b.name}" data-cost="${cost}" ${isChecked ? 'checked' : ''}>
            <span class="emp-benefit-item-name">${b.name}</span>
            <span class="emp-benefit-item-cost">-$${cost.toFixed(2)}/pay (${b.percentage}%)</span>
        `;
        list.appendChild(li);
    });
    updateBenefitsTotal();
}

function updateBenefitsTotal() {
    const checked = document.querySelectorAll('#empBenefitsList input[type="checkbox"]:checked');
    const total = Array.from(checked).reduce((sum, cb) => sum + parseFloat(cb.dataset.cost || 0), 0);
    document.getElementById('empBenefitsTotal').textContent = '$' + total.toFixed(2);
}

document.getElementById('empBenefitsList').addEventListener('change', (e) => {
    if (e.target.matches('input[type="checkbox"]')) updateBenefitsTotal();
});

// ─── Render: profile page ────────────────────────────────────────────────────
function renderProfileInfo() {
    const e = currentEmployee;
    if (!e) return;
    const grid = document.getElementById('empInfoGrid');
    const items = [
        { label: 'First Name', value: e.firstName },
        { label: 'Last Name', value: e.lastName },
        { label: 'Employee ID', value: e.employeeID },
        { label: 'Birth Date', value: e.birthDate },
        { label: 'Email', value: e.email },
        { label: 'Phone', value: e.phone },
        { label: 'Address', value: `${e.address}, ${e.city}, ${e.state} ${e.zip}` },
        { label: 'Job Title', value: e.jobTitle },
        { label: 'Employment Type', value: e.employmentType },
        { label: 'Pay Type', value: e.payType },
    ];
    grid.innerHTML = items.map(item => `
        <div class="emp-info-item">
            <span class="emp-info-label">${item.label}</span>
            <span class="emp-info-value">${item.value || '—'}</span>
        </div>
    `).join('');
}

// ─── Event: change benefit elections on dashboard ────────────────────────────
document.getElementById('empMedical').addEventListener('change', (e) => {
    currentEmployee.medPlan = e.target.value;
    renderPayBreakdown();
});
document.getElementById('empVision').addEventListener('change', (e) => {
    currentEmployee.visPlan = e.target.value;
    renderPayBreakdown();
});
document.getElementById('empSaveBenefitsBtn').addEventListener('click', () => {
    showToast('Benefit elections saved');
});

// ─── Event: save full benefits list on Benefits page ─────────────────────────
document.getElementById('empSaveAllBenefitsBtn').addEventListener('click', () => {
    const checked = Array.from(document.querySelectorAll('#empBenefitsList input[type="checkbox"]:checked'));
    currentEmployee.benefits = checked.map(cb => cb.dataset.name);
    showToast(`Enrolled in ${checked.length} benefit${checked.length === 1 ? '' : 's'}`);
});

// ─── Event: edit profile modal ───────────────────────────────────────────────
const editModal = document.getElementById('empEditModal');
document.getElementById('empEditInfoBtn').addEventListener('click', () => {
    document.getElementById('empEditAddress').value = currentEmployee.address || '';
    document.getElementById('empEditCity').value = currentEmployee.city || '';
    document.getElementById('empEditPhone').value = currentEmployee.phone || '';
    editModal.style.display = 'flex';
});
document.getElementById('empCancelEditBtn').addEventListener('click', () => {
    editModal.style.display = 'none';
});
document.getElementById('empSaveEditBtn').addEventListener('click', () => {
    currentEmployee.address = document.getElementById('empEditAddress').value;
    currentEmployee.city = document.getElementById('empEditCity').value;
    currentEmployee.phone = document.getElementById('empEditPhone').value;
    editModal.style.display = 'none';
    renderProfileInfo();
    showToast('Personal information updated');
});

// ─── Event: generate paycheck ────────────────────────────────────────────────
function numberToWords(amount) {
    const ones = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine',
        'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen',
        'seventeen', 'eighteen', 'nineteen'];
    const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
    function under1000(n) {
        if (n === 0) return '';
        if (n < 20) return ones[n];
        if (n < 100) {
            const t = tens[Math.floor(n / 10)];
            const o = ones[n % 10];
            return o ? `${t}-${o}` : t;
        }
        const hundred = `${ones[Math.floor(n / 100)]} hundred`;
        const rest = n % 100;
        return rest ? `${hundred} ${under1000(rest)}` : hundred;
    }
    const dollars = Math.floor(amount);
    const cents = Math.round((amount - dollars) * 100);
    let words;
    if (dollars === 0) {
        words = 'zero';
    } else {
        const millions = Math.floor(dollars / 1000000);
        const thousands = Math.floor((dollars % 1000000) / 1000);
        const remainder = dollars % 1000;
        const parts = [];
        if (millions) parts.push(`${under1000(millions)} million`);
        if (thousands) parts.push(`${under1000(thousands)} thousand`);
        if (remainder) parts.push(under1000(remainder));
        words = parts.join(' ');
    }
    words = words.charAt(0).toUpperCase() + words.slice(1);
    return `${words} ${cents}/100`;
}

function formatCheckDate(date = new Date()) {
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    const yy = String(date.getFullYear()).slice(-2);
    return `${mm}/${dd}/${yy}`;
}

document.getElementById('empGenerateCheckBtn').addEventListener('click', () => {
    const e = currentEmployee;
    if (e.status !== 'active') {
        showToast('Cannot generate check - status is not active', 'error');
        return;
    }
    const p = calcPay(e);
    const setField = (name, val) => {
        const el = document.querySelector(`#empViewCheck [data-field="${name}"]`);
        if (el) el.textContent = val;
    };
    setField('payeeName', `${e.firstName} ${e.lastName}`);
    setField('date', formatCheckDate());
    setField('amountNumeric', p.net.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
    setField('amountWords', numberToWords(p.net));
    showPage('empViewCheck');
});

document.getElementById('empCancelCheckBtn').addEventListener('click', () => {
    showPage('empDashboard');
});
document.getElementById('empPrintCheckBtn').addEventListener('click', () => {
    window.print();
});

// ─── Initial render ──────────────────────────────────────────────────────────
function init() {
    if (!currentEmployee) {
        showToast('No employee data found', 'error');
        return;
    }
    renderProfileHeader();
    renderPayBreakdown();
    renderBenefitSelects();
    renderBenefitsList();
    renderProfileInfo();
    showPage('empDashboard');
    const initialLink = document.querySelector('[data-target="empDashboard"]');
    if (initialLink) setActiveLink(initialLink);
}

document.addEventListener('DOMContentLoaded', init);
